import { DocumentData, ComparisonResult, FieldComparison } from '../types';

/**
 * Compares 7 mandatory shipping fields between reference SI and draft BL:
 * 1. Shipper
 * 2. Consignee
 * 3. Notify Party
 * 4. Port of Loading (POL)
 * 5. Port of Discharge (POD)
 * 6. Container Count
 * 7. Gross Weight in kilograms
 */
export function compareSevenFields(si: DocumentData, bl: DocumentData): ComparisonResult {
  // 1. Shipper match (entity normalization)
  const cleanShipperSI = normalizeText(si.shipper);
  const cleanShipperBL = normalizeText(bl.shipper);
  const shipperMatch = cleanShipperSI === cleanShipperBL;

  // 2. Consignee match
  const cleanConsigneeSI = normalizeText(si.consignee);
  const cleanConsigneeBL = normalizeText(bl.consignee);
  const consigneeMatch = cleanConsigneeSI === cleanConsigneeBL;

  // 3. Notify Party (handling "Same as Consignee")
  let notifyMatch = false;
  if (si.notifyParty.toLowerCase().includes('same as consignee')) {
    const mainConsigneeName = si.consignee.split(',')[0].trim().toLowerCase();
    notifyMatch = bl.notifyParty.toLowerCase().includes(mainConsigneeName);
  } else {
    notifyMatch = normalizeText(si.notifyParty) === normalizeText(bl.notifyParty);
  }

  // 4. Port of Loading (Handling semantic variation: "Port of Loading" vs "Load Port", UN/LOCODE)
  const polSI = extractPortNameAndCode(si.portOfLoading);
  const polBL = extractPortNameAndCode(bl.portOfLoading);
  const polMatch = polSI === polBL;

  // 5. Port of Discharge (Handling "Port of Discharge" vs "Discharge Port")
  const podSI = extractPortNameAndCode(si.portOfDischarge);
  const podBL = extractPortNameAndCode(bl.portOfDischarge);
  const podMatch = podSI === podBL;

  // 6. Container Count (Numerical comparison - Problem statement example: SI: 2 vs BL: 4)
  const containerMatch = Number(si.containerCount) === Number(bl.containerCount);

  // 7. Gross Weight in kilograms (tolerance check within 1kg)
  const weightMatch = Math.abs(Number(si.grossWeightKg) - Number(bl.grossWeightKg)) < 1;

  const fields: FieldComparison[] = [
    {
      key: 'shipper',
      label: '1. Shipper',
      siVal: si.shipper,
      blVal: bl.shipper,
      match: shipperMatch,
      type: 'exact',
      detail: shipperMatch ? 'Exact entity match' : `SI: ${si.shipper} | BL: ${bl.shipper}`
    },
    {
      key: 'consignee',
      label: '2. Consignee',
      siVal: si.consignee,
      blVal: bl.consignee,
      match: consigneeMatch,
      type: 'exact',
      detail: consigneeMatch ? 'Exact entity match' : `SI: ${si.consignee} | BL: ${bl.consignee}`
    },
    {
      key: 'notifyParty',
      label: '3. Notify Party',
      siVal: si.notifyParty,
      blVal: bl.notifyParty,
      match: notifyMatch,
      type: si.notifyParty.toLowerCase().includes('same as') ? 'semantic' : 'exact',
      detail: notifyMatch ? 'Semantic entity resolution verified' : `SI: ${si.notifyParty} | BL: ${bl.notifyParty}`
    },
    {
      key: 'portOfLoading',
      label: '4. Port of Loading (POL)',
      siVal: si.portOfLoading,
      blVal: bl.portOfLoading,
      match: polMatch,
      type: 'semantic',
      semanticNote: "'Load Port' normalized to 'Port of Loading'",
      detail: polMatch ? 'Port & UN/LOCODE agreed' : `SI: ${si.portOfLoading} | BL: ${bl.portOfLoading}`
    },
    {
      key: 'portOfDischarge',
      label: '5. Port of Discharge (POD)',
      siVal: si.portOfDischarge,
      blVal: bl.portOfDischarge,
      match: podMatch,
      type: 'exact',
      detail: podMatch ? 'Port & UN/LOCODE agreed' : `SI: ${si.portOfDischarge} | BL: ${bl.portOfDischarge}`
    },
    {
      key: 'containerCount',
      label: '6. Container Count',
      siVal: `${si.containerCount} Containers`,
      blVal: `${bl.containerCount} Containers`,
      match: containerMatch,
      type: 'numeric',
      // Explicit requirement: "flag only the container count and show SI: 2 | BL: 4"
      detail: containerMatch ? 'Quantities match exactly' : `SI: ${si.containerCount} | BL: ${bl.containerCount}`
    },
    {
      key: 'grossWeightKg',
      label: '7. Gross Weight (kg)',
      siVal: `${Number(si.grossWeightKg).toLocaleString()} kg`,
      blVal: `${Number(bl.grossWeightKg).toLocaleString()} kg`,
      match: weightMatch,
      type: 'numeric',
      detail: weightMatch ? 'Weight verified in kilograms' : `SI: ${si.grossWeightKg} kg | BL: ${bl.grossWeightKg} kg`
    }
  ];

  const allMatched = fields.every(f => f.match);
  const mismatchCount = fields.filter(f => !f.match).length;

  return {
    allMatched,
    mismatchCount,
    // Explicit requirement: If all seven fields match, report "No mismatch detected."
    reportMessage: allMatched ? 'No mismatch detected' : `${mismatchCount} Discrepancy Found (Requires Attention)`,
    fields
  };
}

function normalizeText(str: string): string {
  return str.toLowerCase().replace(/\s+/g, ' ').replace(/[.,]/g, '').trim();
}

function extractPortNameAndCode(str: string): string {
  return str
    .toLowerCase()
    .replace(/port of loading:|load port:|port of discharge:|discharge port:/gi, '')
    .replace(/[^a-z0-9]/gi, '')
    .trim();
}
