import { EmailRecord } from '../types';

export const INITIAL_EMAILS: EmailRecord[] = [
  {
    id: "msg-001",
    subject: "Draft BL for checking - MSC ULYSSES 402W",
    sender: "msc-docs@medlogistics.com",
    carrier: "MSC",
    receivedAt: "11:20 AM",
    category: "compare_review",
    confidence: 0.99,
    categoryName: "Compare / Review",
    snippet: "Please find attached draft BL alongside SI for verification prior to vessel cutoff.",
    emailBody: "Dear Ops,\nPlease review the attached draft BL for MSC ULYSSES against the SI reference and confirm acceptance. Let us know immediately if any revisions are needed before final printing.",
    attachments: [
      { id: "att-1", name: "SI_Ref_MSCU402W.txt", type: "SI", label: "Shipping Instruction (Reference)" },
      { id: "att-2", name: "Draft_BL_MEDU12984.txt", type: "BL", label: "Draft Bill of Lading" }
    ],
    siData: {
      shipper: "Apex Global Logistics Pte Ltd, 10 Collyer Quay, Singapore",
      consignee: "Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
      notifyParty: "Same as Consignee",
      portOfLoading: "Port of Loading: Singapore (SGSIN)",
      portOfDischarge: "Port of Discharge: Rotterdam (NLRTM)",
      containerCount: 2, // PROBLEM STATEMENT: 2 containers
      grossWeightKg: 22000, // PROBLEM STATEMENT: 22,000 kg
      rawLines: [
        "=== SHIPPING INSTRUCTION (REFERENCE) ===",
        "Booking Ref: MSC-BKG-992144",
        "Shipper: Apex Global Logistics Pte Ltd, 10 Collyer Quay, Singapore",
        "Consignee: Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
        "Notify Party: Same as Consignee",
        "Port of Loading: Singapore (SGSIN)",
        "Port of Discharge: Rotterdam (NLRTM)",
        "Containers: 2 x 40' High Cube (TGHU9821440, MSCU7721092)",
        "Gross Weight: 22,000.00 KGS",
        "Freight: Prepaid"
      ]
    },
    blData: {
      shipper: "Apex Global Logistics Pte Ltd, 10 Collyer Quay, Singapore",
      consignee: "Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
      notifyParty: "Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
      portOfLoading: "Load Port: Singapore (SGSIN)", // SEMANTIC VARIATION
      portOfDischarge: "Port of Discharge: Rotterdam (NLRTM)",
      containerCount: 4, // PROBLEM STATEMENT: 4 containers (MISMATCH!)
      grossWeightKg: 22000, // 22,000 kg (MATCHES)
      rawLines: [
        "=== DRAFT BILL OF LADING ===",
        "BL Number: MEDU12984-DRAFT",
        "Shipper: Apex Global Logistics Pte Ltd, 10 Collyer Quay, Singapore",
        "Consignee: Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
        "Notify: Nordic Retailers BV, Maasvlakte 45, Rotterdam, Netherlands",
        "Load Port: Singapore (SGSIN)",
        "Port of Discharge: Rotterdam (NLRTM)",
        "Containers: 4 x 40' High Cube (TGHU9821440, MSCU7721092, MSCU1102931, TEMU9921004)",
        "Gross Weight: 22,000.00 KGS",
        "Freight: Prepaid"
      ]
    },
    status: "mismatch_flagged"
  },
  {
    id: "msg-002",
    subject: "Draft BL verification: Maersk Honam 2401",
    sender: "export.sea@maersk.com",
    carrier: "Maersk",
    receivedAt: "10:45 AM",
    category: "compare_review",
    confidence: 0.98,
    categoryName: "Compare / Review",
    snippet: "Attached is the Maersk draft BL and SI for voyage 2401. Please inspect all 7 fields.",
    emailBody: "Hi team, please review attached SI and draft BL. All details should conform to customer booking instructions.",
    attachments: [
      { id: "att-3", name: "SI_Maersk_2401.txt", type: "SI", label: "Shipping Instruction (Reference)" },
      { id: "att-4", name: "BL_Draft_MAEU99210.txt", type: "BL", label: "Draft Bill of Lading" }
    ],
    siData: {
      shipper: "Yokohama Chemical Exports Inc, Yokohama, Japan",
      consignee: "EuroChem Distribution GmbH, Hamburg, Germany",
      notifyParty: "EuroChem Logistics Office, Hamburg",
      portOfLoading: "Port of Loading: Yokohama (JPYOK)",
      portOfDischarge: "Port of Discharge: Hamburg (DEHAM)",
      containerCount: 3,
      grossWeightKg: 45200,
      rawLines: [
        "=== SHIPPING INSTRUCTION (REFERENCE) ===",
        "Booking Ref: MAEU-772109",
        "Shipper: Yokohama Chemical Exports Inc, Yokohama, Japan",
        "Consignee: EuroChem Distribution GmbH, Hamburg, Germany",
        "Notify Party: EuroChem Logistics Office, Hamburg",
        "Port of Loading: Yokohama (JPYOK)",
        "Port of Discharge: Hamburg (DEHAM)",
        "Containers: 3 x 20' Standard",
        "Gross Weight: 45,200.00 KGS",
        "Status: Final SI"
      ]
    },
    blData: {
      shipper: "Yokohama Chemical Exports Inc, Yokohama, Japan",
      consignee: "EuroChem Distribution GmbH, Hamburg, Germany",
      notifyParty: "EuroChem Logistics Office, Hamburg",
      portOfLoading: "Load Port: Yokohama (JPYOK)", // Semantic match
      portOfDischarge: "Port of Discharge: Hamburg (DEHAM)",
      containerCount: 3,
      grossWeightKg: 45200,
      rawLines: [
        "=== DRAFT BILL OF LADING ===",
        "Draft B/L: MAEU99210-DRAFT",
        "Shipper: Yokohama Chemical Exports Inc, Yokohama, Japan",
        "Consignee: EuroChem Distribution GmbH, Hamburg, Germany",
        "Notify: EuroChem Logistics Office, Hamburg",
        "Load Port: Yokohama (JPYOK)",
        "Port of Discharge: Hamburg (DEHAM)",
        "Containers: 3 x 20' Standard",
        "Gross Weight: 45,200.00 KGS",
        "Clean on Board"
      ]
    },
    status: "verified_match" // All 7 fields match -> "No mismatch detected"
  },
  {
    id: "msg-003",
    subject: "Review requested: CMA CGM TIVOLI - Heavy Machinery",
    sender: "doc.asia@cma-cgm.com",
    carrier: "CMA CGM",
    receivedAt: "09:15 AM",
    category: "compare_review",
    confidence: 0.94,
    categoryName: "Compare / Review",
    snippet: "Draft BL and SI for heavy equipment shipment attached. Weight tolerance query.",
    emailBody: "Draft attached. Note: gross weight in BL includes tare weight calculation. Please check.",
    attachments: [
      { id: "att-5", name: "SI_CMA_Tivoli.txt", type: "SI", label: "Shipping Instruction (Reference)" },
      { id: "att-6", name: "BL_Draft_CMA9011.txt", type: "BL", label: "Draft Bill of Lading" }
    ],
    siData: {
      shipper: "Bavaria Machinery Works AG, Munich",
      consignee: "Shanghai Heavy Industries Co, Shanghai",
      notifyParty: "Shanghai Freight Forwarding Ltd",
      portOfLoading: "Port of Loading: Antwerp (BEANR)",
      portOfDischarge: "Port of Discharge: Shanghai (CNSHA)",
      containerCount: 1,
      grossWeightKg: 18500,
      rawLines: [
        "=== SHIPPING INSTRUCTION ===",
        "Shipper: Bavaria Machinery Works AG, Munich",
        "Consignee: Shanghai Heavy Industries Co, Shanghai",
        "Notify: Shanghai Freight Forwarding Ltd",
        "Port of Loading: Antwerp (BEANR)",
        "Port of Discharge: Shanghai (CNSHA)",
        "Container Count: 1 x 40' Flat Rack",
        "Gross Weight: 18,500 KGS"
      ]
    },
    blData: {
      shipper: "Bavaria Machinery Works AG, Munich",
      consignee: "Shanghai Heavy Industries Co, Shanghai",
      notifyParty: "Shanghai Freight Forwarding Ltd",
      portOfLoading: "Load Port: Antwerp (BEANR)",
      portOfDischarge: "Port of Discharge: Shanghai (CNSHA)",
      containerCount: 1,
      grossWeightKg: 21900, // Weight mismatch -> triggers Escalation
      rawLines: [
        "=== DRAFT BILL OF LADING ===",
        "Shipper: Bavaria Machinery Works AG, Munich",
        "Consignee: Shanghai Heavy Industries Co, Shanghai",
        "Notify: Shanghai Freight Forwarding Ltd",
        "Load Port: Antwerp (BEANR)",
        "Port of Discharge: Shanghai (CNSHA)",
        "Container Count: 1 x 40' Flat Rack",
        "Gross Weight: 21,900 KGS"
      ]
    },
    status: "escalated"
  },
  {
    id: "msg-004",
    subject: "Invoice Dispute: Demurrage charges on MEDU882103",
    sender: "accounts@nordictrade.com",
    carrier: "Nordic Trade",
    receivedAt: "08:50 AM",
    category: "invoice_queries",
    confidence: 0.97,
    categoryName: "Invoice Queries",
    snippet: "We were charged demurrage fees at Rotterdam terminal despite container being returned on time...",
    emailBody: "Dear Finance, regarding invoice INV-2026-9812, we dispute the 3-day detention fee as empty container was gated in on Sept 18.",
    attachments: [
      { id: "att-7", name: "Disputed_Invoice_9812.pdf", type: "INV", label: "Invoice" }
    ],
    status: "routed_finance"
  },
  {
    id: "msg-005",
    subject: "Instructions to prepare new SI for booking HLCU881023",
    sender: "ops@shippers-union.org",
    carrier: "Hapag-Lloyd",
    receivedAt: "08:30 AM",
    category: "prepare_si",
    confidence: 0.95,
    categoryName: "Prepare New SI",
    snippet: "Please prepare and submit a new Shipping Instruction for 5x40HC to Genoa before 5 PM today.",
    emailBody: "Hi, please create the SI draft using the attached commercial invoice and packing list for HLCU881023.",
    attachments: [
      { id: "att-8", name: "Packing_List_Genoa.xlsx", type: "DOC", label: "Packing List" }
    ],
    status: "routed_si_desk"
  },
  {
    id: "msg-006",
    subject: "Exclusive Offer: Discounted ocean freight rates Q4",
    sender: "promo@globalfreight-leads.xyz",
    carrier: "External",
    receivedAt: "07:15 AM",
    category: "spam",
    confidence: 0.99,
    categoryName: "Spam",
    snippet: "Increase your margins! Click here to view bulk container slots at 40% discount.",
    emailBody: "Click to claim your freight discount today...",
    attachments: [],
    status: "quarantined"
  }
];
