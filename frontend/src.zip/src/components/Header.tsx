import React from 'react';
import { FileCheck, Mail, Search, AlertTriangle, BarChart3, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeTab: 'inbox' | 'studio' | 'escalations' | 'analytics';
  onTabChange: (tab: 'inbox' | 'studio' | 'escalations' | 'analytics') => void;
  unreadCount: number;
  escalationCount: number;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  unreadCount,
  escalationCount,
  onReset
}) => {
  return (
    <header className="bg-slate-950 border-b border-slate-800 px-6 py-3 flex items-center justify-between sticky top-0 z-30 shadow-md">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-blue-600 via-indigo-500 to-teal-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <FileCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-base tracking-tight text-white flex items-center gap-2">
              NaviDoc <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">OPS VERIFIER</span>
            </h1>
            <p className="text-xs text-slate-400">Automated Shipping Document Cross-Check & Inbox Triage</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center ml-8 gap-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onTabChange('inbox')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${
              activeTab === 'inbox'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Unified Inbox</span>
            <span className="bg-indigo-400/30 text-indigo-200 text-[10px] px-1.5 py-0.2 rounded-full font-bold">
              {unreadCount}
            </span>
          </button>

          <button
            onClick={() => onTabChange('studio')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${
              activeTab === 'studio'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Verification Studio</span>
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
          </button>

          <button
            onClick={() => onTabChange('escalations')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${
              activeTab === 'escalations'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Escalation Queue</span>
            {escalationCount > 0 && (
              <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                {escalationCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onTabChange('analytics')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${
              activeTab === 'analytics'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Ops Analytics</span>
          </button>
        </nav>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        <div className="hidden lg:flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>Reference Standard: <strong className="text-white">SI is Ground Truth</strong></span>
        </div>
        <button
          onClick={onReset}
          title="Reset mock data to initial baseline"
          className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Demo</span>
        </button>
      </div>
    </header>
  );
};
