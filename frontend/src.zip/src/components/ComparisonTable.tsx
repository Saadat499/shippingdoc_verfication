import React from 'react';
import { ComparisonResult, FieldComparison } from '../types';
import { CheckCircle2, AlertOctagon, HelpCircle, Sparkles } from 'lucide-react';

interface ComparisonTableProps {
  comparison: ComparisonResult;
  onHoverField: (fieldKey: string | null) => void;
}

export const ComparisonTable: React.FC<ComparisonTableProps> = ({
  comparison,
  onHoverField,
}) => {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Top Banner (Problem Statement requirement: "If all seven fields match, report 'No mismatch detected'.") */}
      <div
        className={`p-4 border-b shrink-0 transition-all ${
          comparison.allMatched
            ? 'bg-emerald-950/40 border-emerald-500/30'
            : 'bg-rose-950/40 border-rose-500/30'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
              comparison.allMatched
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold'
            }`}
          >
            {comparison.allMatched ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <AlertOctagon className="w-5 h-5" />
            )}
          </div>
          <div>
            <h3
              className={`font-bold text-sm ${
                comparison.allMatched ? 'text-emerald-300' : 'text-rose-300'
              }`}
            >
              {comparison.allMatched ? 'No mismatch detected' : `${comparison.mismatchCount} Mismatch Detected`}
            </h3>
            <p
              className={`text-xs ${
                comparison.allMatched ? 'text-emerald-400/80' : 'text-rose-400/80'
              }`}
            >
              {comparison.allMatched
                ? 'All 7 fields in agreement with SI reference. Ready for immediate sign-off.'
                : 'Discrepancies found against SI reference. Draft BL must be amended before cutoff.'}
            </p>
          </div>
        </div>
      </div>

      {/* Header bar */}
      <div className="bg-slate-900/90 px-4 py-2 border-b border-slate-800 flex items-center justify-between shrink-0">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300">
          The 7 Verification Fields
        </span>
        <span className="text-[10px] text-slate-500">Target: 7 / 7 Verified</span>
      </div>

      {/* Fields List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80">
        {comparison.fields.map((f: FieldComparison) => {
          return (
            <div
              key={f.key}
              onMouseEnter={() => onHoverField(f.key)}
              onMouseLeave={() => onHoverField(null)}
              className={`p-3.5 transition-colors cursor-pointer ${
                f.match
                  ? 'hover:bg-slate-900/70'
                  : 'bg-rose-950/20 hover:bg-rose-950/30 border-l-4 border-rose-500'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span
                  className={`font-bold text-xs ${
                    f.match ? 'text-slate-200' : 'text-rose-300'
                  }`}
                >
                  {f.label}
                </span>

                {f.match ? (
                  f.type === 'semantic' ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Semantic Match
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Match
                    </span>
                  )
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse flex items-center gap-1">
                    <AlertOctagon className="w-3 h-3" /> MISMATCH
                  </span>
                )}
              </div>

              {/* SI vs BL comparison values */}
              <div className="space-y-1 text-xs font-mono">
                <div className="flex items-start justify-between bg-slate-900/70 p-1.5 rounded">
                  <span className="text-slate-400 text-[10px] shrink-0 w-16">SI (Ref):</span>
                  <span className="text-emerald-300 text-right font-medium truncate">{f.siVal}</span>
                </div>
                <div className="flex items-start justify-between bg-slate-900/70 p-1.5 rounded">
                  <span className="text-slate-400 text-[10px] shrink-0 w-16">BL (Draft):</span>
                  <span
                    className={`${
                      f.match ? 'text-blue-300' : 'text-rose-400 font-bold'
                    } text-right truncate`}
                  >
                    {f.blVal}
                  </span>
                </div>
              </div>

              {/* Attention line for mismatch (Exact format: SI: 2 | BL: 4) */}
              {!f.match ? (
                <div className="mt-2 text-[11px] font-mono bg-rose-900/30 text-rose-200 p-1.5 rounded border border-rose-500/30 flex items-center justify-between">
                  <span>Attention:</span>
                  <strong className="font-bold">{f.detail}</strong>
                </div>
              ) : f.semanticNote ? (
                <div className="mt-1.5 text-[10px] text-indigo-400 flex items-center gap-1">
                  <HelpCircle className="w-3 h-3" />
                  <span>{f.semanticNote}</span>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-900/60 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between shrink-0">
        <span>
          Reference Document: <strong className="text-white">SI (Ground Truth)</strong>
        </span>
        <span className="text-slate-500">Auto-checked at: Today</span>
      </div>
    </div>
  );
};
