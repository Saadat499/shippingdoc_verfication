import React, { useState } from 'react';
import { EmailRecord } from '../types';
import { compareSevenFields } from '../utils/comparator';
import { ComparisonTable } from './ComparisonTable';
import { ArrowLeft, AlertTriangle, Send, Check, Sparkles, FileText } from 'lucide-react';

interface VerificationStudioProps {
  email: EmailRecord;
  onBack: () => void;
  onOpenEscalation: () => void;
  onOpenAmendment: () => void;
  onApproveBL: () => void;
}

export const VerificationStudio: React.FC<VerificationStudioProps> = ({
  email,
  onBack,
  onOpenEscalation,
  onOpenAmendment,
  onApproveBL,
}) => {
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);

  if (!email.siData || !email.blData) {
    return (
      <div className="flex-1 flex items-center justify-center p-6 text-slate-400">
        <p>No document comparison data available for this email.</p>
      </div>
    );
  }

  const comparison = compareSevenFields(email.siData, email.blData);

  const getHighlightClass = (line: string) => {
    if (!highlightedKey) return 'py-0.5 px-1.5 rounded transition-all';

    const lower = line.toLowerCase();
    const keyMap: Record<string, string[]> = {
      shipper: ['shipper'],
      consignee: ['consignee'],
      notifyParty: ['notify'],
      portOfLoading: ['loading', 'load port'],
      portOfDischarge: ['discharge'],
      containerCount: ['container'],
      grossWeightKg: ['weight', 'gross'],
    };

    const targets = keyMap[highlightedKey] || [];
    const isTarget = targets.some((t) => lower.includes(t));

    if (!isTarget) return 'py-0.5 px-1.5 rounded transition-all';

    const fieldObj = comparison.fields.find((f) => f.key === highlightedKey);
    if (fieldObj && !fieldObj.match) {
      return 'py-0.5 px-1.5 rounded transition-all bg-rose-500/20 text-rose-200 border-l-2 border-rose-500 font-bold';
    }
    return 'py-0.5 px-1.5 rounded transition-all bg-emerald-500/20 text-emerald-200 border-l-2 border-emerald-500';
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 max-w-full w-full mx-auto space-y-4 overflow-hidden h-[calc(100vh-65px)]">
      {/* Studio Header Bar */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors"
            title="Back to Inbox"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">{email.subject}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                Compare / Review
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300">
                {(email.confidence * 100).toFixed(1)}% Match
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              From: {email.sender} • Received: {email.receivedAt} • Carrier: {email.carrier}
            </p>
          </div>
        </div>

        {/* Right Action Bar */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenEscalation}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors flex items-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Ask For Help / Escalate</span>
          </button>

          {!comparison.allMatched && (
            <button
              onClick={onOpenAmendment}
              className="px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 transition-colors flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Draft Carrier Amendment</span>
            </button>
          )}

          <button
            onClick={onApproveBL}
            disabled={!comparison.allMatched}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              comparison.allMatched
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-900/30 cursor-pointer'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>Approve BL Draft</span>
          </button>
        </div>
      </div>

      {/* 3-PANE WORKSPACE */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 overflow-hidden min-h-0">
        
        {/* PANE 1: Email Metadata & Attachments (3 cols) */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col space-y-4 overflow-y-auto">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
              Step 01 & 02 Intake Context
            </span>
            <h3 className="text-xs font-semibold text-slate-200 mt-1">Inbound Message Record</h3>
          </div>

          <div className="bg-slate-900/90 rounded-lg p-3 border border-slate-800 space-y-2 text-xs">
            <div>
              <span className="text-slate-500 block text-[10px]">SUBJECT</span>
              <p className="font-medium text-slate-200">{email.subject}</p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
              <div>
                <span className="text-slate-500 block text-[10px]">MSG TYPE</span>
                <span className="text-indigo-400 font-semibold">Compare / Review</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">STATUS</span>
                <span className="text-emerald-400 font-semibold">Active Checked</span>
              </div>
            </div>
            <div className="pt-1 border-t border-slate-800/80">
              <span className="text-slate-500 block text-[10px]">EMAIL BODY EXTRACT</span>
              <p className="text-slate-300 text-[11px] leading-relaxed italic bg-slate-950 p-2 rounded border border-slate-800/60 mt-1">
                "{email.emailBody}"
              </p>
            </div>
          </div>

          {/* Attachments Section */}
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
              Extracted Attachments
            </span>
            <div className="space-y-2 mt-2">
              {email.attachments.map((att) => (
                <div
                  key={att.id}
                  className={`p-2 rounded-lg border text-xs flex items-center justify-between ${
                    att.type === 'SI'
                      ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                      : 'bg-blue-950/20 border-blue-500/30 text-blue-300'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        att.type === 'SI' ? 'bg-emerald-500/20' : 'bg-blue-500/20'
                      }`}
                    >
                      {att.type}
                    </span>
                    <span className="font-mono text-[11px] truncate">{att.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 shrink-0">
                    {att.type === 'SI' ? 'Ref Document' : 'Target Draft'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Semantic Alias Status */}
          <div className="mt-auto bg-indigo-950/20 border border-indigo-500/20 rounded-lg p-3 text-xs">
            <div className="flex items-center gap-1.5 text-indigo-400 font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Semantic Alias Resolver</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Automated synonym normalization active. E.g., <code className="text-indigo-300 font-mono">"Load Port"</code> mapped directly to canonical field <code className="text-indigo-300 font-mono">"Port of Loading"</code>.
            </p>
          </div>
        </div>

        {/* PANE 2: Dual Synchronized Document Viewer (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-400" />
              <span className="text-xs font-bold text-slate-200">Dual Document Inspector</span>
              <span className="text-[10px] text-slate-400">(Hover field in table to cross-highlight)</span>
            </div>
            <span className="text-[11px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700">
              Side-by-Side Sync
            </span>
          </div>

          {/* Panes */}
          <div className="flex-1 grid grid-cols-2 divide-x divide-slate-800 overflow-hidden text-xs">
            {/* SI Reference (Left) */}
            <div className="flex flex-col h-full overflow-hidden bg-slate-950">
              <div className="bg-emerald-950/30 px-3 py-2 border-b border-emerald-500/20 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="font-bold text-emerald-300 text-xs">Shipping Instruction (SI)</span>
                </div>
                <span className="text-[10px] uppercase tracking-wider bg-emerald-500/20 text-emerald-300 font-semibold px-1.5 py-0.5 rounded">
                  Ground Truth
                </span>
              </div>
              <div className="flex-1 p-3 overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300 space-y-1 select-text">
                {email.siData.rawLines.map((line, idx) => (
                  <div key={idx} className={getHighlightClass(line)}>
                    {line}
                  </div>
                ))}
              </div>
            </div>

            {/* Draft BL (Right) */}
            <div className="flex flex-col h-full overflow-hidden bg-slate-950">
              <div className="bg-blue-950/30 px-3 py-2 border-b border-blue-500/20 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                  <span className="font-bold text-blue-300 text-xs">Draft Bill of Lading (BL)</span>
                </div>
                <span className="text-[10px] uppercase tracking-wider bg-blue-500/20 text-blue-300 font-semibold px-1.5 py-0.5 rounded">
                  Draft under check
                </span>
              </div>
              <div className="flex-1 p-3 overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300 space-y-1 select-text">
                {email.blData.rawLines.map((line, idx) => (
                  <div key={idx} className={getHighlightClass(line)}>
                    {line}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* PANE 3: 7-Field Comparison Inspector (4 cols) */}
        <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <ComparisonTable
            comparison={comparison}
            onHoverField={(key) => setHighlightedKey(key)}
          />
        </div>

      </div>
    </div>
  );
};
