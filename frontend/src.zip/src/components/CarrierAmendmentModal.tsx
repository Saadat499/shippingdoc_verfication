import React, { useState, useEffect } from 'react';
import { EmailRecord } from '../types';
import { compareSevenFields } from '../utils/comparator';
import { Send, X, Check } from 'lucide-react';

interface CarrierAmendmentModalProps {
  email: EmailRecord;
  isOpen: boolean;
  onClose: () => void;
  onSend: () => void;
}

export const CarrierAmendmentModal: React.FC<CarrierAmendmentModalProps> = ({
  email,
  isOpen,
  onClose,
  onSend,
}) => {
  const [recipient, setRecipient] = useState(email.sender);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  useEffect(() => {
    if (!email.siData || !email.blData) return;
    const comp = compareSevenFields(email.siData, email.blData);

    setRecipient(email.sender);
    setSubject(
      `URGENT: Draft BL Discrepancy Notice - ${email.carrier} (${email.subject})`
    );

    let discrepancyList = '';
    if (!comp.allMatched) {
      comp.fields
        .filter((f) => !f.match)
        .forEach((f) => {
          discrepancyList += `* Field: ${f.label}\n  - Required (SI Reference): ${f.siVal}\n  - Received on Draft BL: ${f.blVal}\n  - Discrepancy Flag: ${f.detail}\n\n`;
        });
    }

    setBody(
      `Dear ${email.carrier} Documentation Team,\n\nWe have performed automated cross-verification of your Draft BL against our Reference Shipping Instruction (SI).\n\nPlease amend the following fields to match the SI before final issuance:\n\n${discrepancyList}Please send the revised draft as soon as possible to avoid cut-off delays.\n\nBest regards,\nShipping Operations Desk`
    );
  }, [email, isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Draft Carrier Amendment Request</h3>
              <p className="text-xs text-slate-400">
                Pre-generated correction notice based on SI vs Draft BL diff
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">To:</label>
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-200 text-xs font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">Subject:</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-200 text-xs font-medium"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">Message Body:</label>
            <textarea
              rows={8}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-[11px] leading-relaxed"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-[11px] text-emerald-400 flex items-center gap-1">
            <Check className="w-3.5 h-3.5" />
            Formatted with exact SI reference values
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800"
            >
              Cancel
            </button>
            <button
              onClick={onSend}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-900/40 flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Amendment Notice</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
