import React, { useState } from 'react';
import { EmailRecord } from '../types';
import { compareSevenFields } from '../utils/comparator';
import { AlertTriangle, X } from 'lucide-react';

interface EscalationModalProps {
  email: EmailRecord;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (action: string, notes: string) => void;
}

export const EscalationModal: React.FC<EscalationModalProps> = ({
  email,
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [selectedAction, setSelectedAction] = useState('enforce_si');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const comp =
    email.siData && email.blData ? compareSevenFields(email.siData, email.blData) : null;

  const mismatches =
    comp && !comp.allMatched
      ? comp.fields
          .filter((f) => !f.match)
          .map((f) => `${f.label}: ${f.detail}`)
          .join(', ')
      : 'Manual supervisor escalation requested';

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Escalate to Senior Operations</h3>
              <p className="text-xs text-slate-400">
                Step 04: Human-in-the-loop triage with preserved audit context
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Full context summary */}
        <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 space-y-2.5 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-400">Target Shipment:</span>
            <span className="font-mono font-bold text-white">{email.subject}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Flagged Issue:</span>
            <span className="font-bold text-rose-400">{mismatches}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Risk Assessment:</span>
            <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-semibold text-[10px]">
              CRITICAL CUSTOMS IMPACT
            </span>
          </div>
        </div>

        {/* Operator Resolution Actions */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Operator Resolution Action:</label>
          <div className="space-y-2 text-xs">
            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-800 bg-slate-900/50 hover:bg-slate-800 cursor-pointer">
              <input
                type="radio"
                name="esc-action"
                value="enforce_si"
                checked={selectedAction === 'enforce_si'}
                onChange={(e) => setSelectedAction(e.target.value)}
                className="text-indigo-600 focus:ring-0"
              />
              <span>
                <strong>Enforce SI (Reference):</strong> Reject BL & require carrier to correct container count as per SI.
              </span>
            </label>

            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-800 bg-slate-900/50 hover:bg-slate-800 cursor-pointer">
              <input
                type="radio"
                name="esc-action"
                value="accept_bl"
                checked={selectedAction === 'accept_bl'}
                onChange={(e) => setSelectedAction(e.target.value)}
                className="text-indigo-600 focus:ring-0"
              />
              <span>
                <strong>Accept Draft BL:</strong> Shipper authorized container update in late booking revision.
              </span>
            </label>

            <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-800 bg-slate-900/50 hover:bg-slate-800 cursor-pointer">
              <input
                type="radio"
                name="esc-action"
                value="request_shipper"
                checked={selectedAction === 'request_shipper'}
                onChange={(e) => setSelectedAction(e.target.value)}
                className="text-indigo-600 focus:ring-0"
              />
              <span>
                <strong>Query Shipper:</strong> Contact shipper directly to confirm intended container booking count.
              </span>
            </label>
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="text-xs font-semibold text-slate-300">Internal Audit Note:</label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g., Booking amended yesterday, awaiting revised BL draft from carrier..."
            className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800"
          >
            Cancel
          </button>
          <button
            onClick={() => onSubmit(selectedAction, notes)}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 shadow-lg shadow-amber-900/30"
          >
            Confirm Escalation & Log
          </button>
        </div>
      </div>
    </div>
  );
};
