import React from 'react';
import { BarChart3, TrendingUp, AlertOctagon, CheckCircle2 } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col p-6 max-w-7xl w-full mx-auto space-y-6 overflow-y-auto">
      <div>
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-indigo-400" />
          Shipping Operations & Document Verification Metrics
        </h2>
        <p className="text-xs text-slate-400">
          Real-time Straight-Through Processing (STP) and Field Mismatch Analytics
        </p>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-xs text-slate-400 font-medium">Inbound Emails Today</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-white">142</span>
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> +18% vs avg
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">100% categorized via Step 01 NLP</p>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-xs text-slate-400 font-medium">Document Check Requests</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-indigo-400">18</span>
            <span className="text-xs text-slate-400">12.6% of Inbox</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Passed to extraction & 7-field check</p>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-xs text-slate-400 font-medium">Straight-Through Processing (STP)</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-emerald-400">72.2%</span>
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-0.5">
              <CheckCircle2 className="w-3 h-3" /> "No mismatch"
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Zero human touch BL approval</p>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-xs text-slate-400 font-medium">Discrepancy Catch Rate</span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl font-bold text-rose-400">27.8%</span>
            <span className="text-xs text-amber-400 font-semibold flex items-center gap-0.5">
              <AlertOctagon className="w-3 h-3" /> 5 Discrepancies
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Intercepted before final carrier issuance</p>
        </div>
      </div>

      {/* Charts & Tables Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Field Discrepancy Frequency Chart (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Discrepancy Breakdown by Field (Last 30 Days)
              </h3>
              <p className="text-[11px] text-slate-400">
                Which of the 7 core fields generate the most draft errors?
              </p>
            </div>
            <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-1 rounded">
              Sample: 340 drafts
            </span>
          </div>

          {/* Bar Chart Visualizer */}
          <div className="space-y-3.5 my-auto pt-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">1. Container Count</span>
                <span className="font-bold text-rose-400">38% (High Risk)</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-rose-500 h-2.5 rounded-full" style={{ width: '38%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">2. Gross Weight (kg)</span>
                <span className="font-bold text-amber-400">27%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '27%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">3. Port of Loading / Discharge</span>
                <span className="font-bold text-indigo-400">16%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: '16%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">4. Consignee</span>
                <span className="font-bold text-slate-400">11%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-slate-600 h-2.5 rounded-full" style={{ width: '11%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">5. Shipper</span>
                <span className="font-bold text-slate-400">5%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-slate-600 h-2.5 rounded-full" style={{ width: '5%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-200">6. Notify Party</span>
                <span className="font-bold text-slate-400">3%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
                <div className="bg-slate-600 h-2.5 rounded-full" style={{ width: '3%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Carrier Accuracy Leaderboard (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
            Carrier Draft Accuracy
          </h3>
          <p className="text-[11px] text-slate-400 mb-4">
            First-pass accuracy score across shipping lines
          </p>

          <div className="space-y-3 divide-y divide-slate-800/80">
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-xs font-medium text-white">Maersk Line</span>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400">94.2% Accurate</span>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-xs font-medium text-white">Hapag-Lloyd</span>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400">91.8% Accurate</span>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span className="text-xs font-medium text-white">MSC (Mediterranean Shipping)</span>
              </div>
              <span className="text-xs font-mono font-bold text-amber-400">86.4% Accurate</span>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400"></span>
                <span className="text-xs font-medium text-white">CMA CGM</span>
              </div>
              <span className="text-xs font-mono font-bold text-rose-400">81.5% Accurate</span>
            </div>
          </div>

          <div className="mt-auto pt-4 bg-slate-900/60 p-3 rounded-lg border border-slate-800 text-[11px] text-slate-400">
            💡 <strong>Insight:</strong> Container count mismatches (e.g. SI: 2 vs BL: 4) constitute 38% of errors, usually originating from booking amendment lag at the carrier desk.
          </div>
        </div>

      </div>
    </div>
  );
};
