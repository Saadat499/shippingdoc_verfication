import React, { useState } from 'react';
import { EmailRecord, MessageCategory } from '../types';
import { compareSevenFields } from '../utils/comparator';
import { Search, FileText, CheckCircle2, AlertOctagon, AlertTriangle, ArrowRight, ShieldCheck } from 'lucide-react';

interface InboxViewProps {
  emails: EmailRecord[];
  activeEmailId: string;
  onSelectEmail: (id: string) => void;
  onOpenStudio: (id: string) => void;
}

export const InboxView: React.FC<InboxViewProps> = ({
  emails,
  activeEmailId,
  onSelectEmail,
  onOpenStudio,
}) => {
  const [filter, setFilter] = useState<MessageCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEmails = emails.filter((e) => {
    const matchesFilter = filter === 'all' || e.category === filter;
    const matchesSearch =
      searchQuery === '' ||
      e.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.carrier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.sender.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="flex-1 flex flex-col p-6 max-w-7xl w-full mx-auto space-y-5 overflow-y-auto">
      {/* Step 01 Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold text-sm shrink-0">
            01
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              Step 01: Message Intake & Automated Classification Pipeline
              <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                Multi-class NLP Routing
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Automatically filters spam, invoices, and IT requests. Only{' '}
              <span className="text-indigo-300 font-medium underline decoration-indigo-500">
                Document Comparison requests
              </span>{' '}
              proceed to extraction and 7-field automated check.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-slate-400">Classified Today:</span>
          <span className="text-xs font-bold text-white bg-slate-800 px-2 py-1 rounded border border-slate-700">
            142 Messages
          </span>
          <span className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-1 rounded flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> 100% Triaged
          </span>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filter === 'all'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            All <span className="ml-1 opacity-70">({emails.length})</span>
          </button>
          <button
            onClick={() => setFilter('compare_review')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              filter === 'compare_review'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <span>🎯 Compare / Review</span>
            <span className="px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 text-[10px]">
              {emails.filter((e) => e.category === 'compare_review').length}
            </span>
          </button>
          <button
            onClick={() => setFilter('invoice_queries')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filter === 'invoice_queries'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            🧾 Invoices <span className="ml-1 opacity-70">(1)</span>
          </button>
          <button
            onClick={() => setFilter('prepare_si')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filter === 'prepare_si'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            📝 Prepare New SI <span className="ml-1 opacity-70">(1)</span>
          </button>
          <button
            onClick={() => setFilter('it_requests')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filter === 'it_requests'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            💻 IT Requests <span className="ml-1 opacity-70">(0)</span>
          </button>
          <button
            onClick={() => setFilter('spam')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filter === 'spam'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            🚫 Spam <span className="ml-1 opacity-70">(1)</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search carrier, SI#, subject..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
      </div>

      {/* Emails Table */}
      <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-slate-400 uppercase font-semibold tracking-wider text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 w-8">#</th>
                <th className="py-3 px-4">Classification & Category</th>
                <th className="py-3 px-4">Sender / Carrier</th>
                <th className="py-3 px-4">Subject & Email Snippet</th>
                <th className="py-3 px-4">Attachments Extracted</th>
                <th className="py-3 px-4">7-Field Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredEmails.map((email, idx) => {
                const comp =
                  email.category === 'compare_review' && email.siData && email.blData
                    ? compareSevenFields(email.siData, email.blData)
                    : null;

                const isSelected = email.id === activeEmailId;

                return (
                  <tr
                    key={email.id}
                    onClick={() => onSelectEmail(email.id)}
                    className={`hover:bg-slate-900/90 transition-colors cursor-pointer ${
                      isSelected ? 'bg-slate-900/60 border-l-2 border-indigo-500' : ''
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono text-slate-500">{idx + 1}</td>

                    {/* Category pill */}
                    <td className="py-3.5 px-4">
                      <div className="flex flex-col gap-1 items-start">
                        {email.category === 'compare_review' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span> Compare / Review
                          </span>
                        )}
                        {email.category === 'invoice_queries' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                            🧾 Invoice Query
                          </span>
                        )}
                        {email.category === 'prepare_si' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20">
                            📝 Prepare New SI
                          </span>
                        )}
                        {email.category === 'spam' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-700/40 text-slate-400 border border-slate-700">
                            🚫 Spam
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-mono">
                          {(email.confidence * 100).toFixed(1)}% confidence
                        </span>
                      </div>
                    </td>

                    {/* Sender */}
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-white block">{email.carrier}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{email.sender}</span>
                    </td>

                    {/* Subject */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <span className="font-medium text-slate-200 block truncate">{email.subject}</span>
                      <span className="text-[11px] text-slate-400 truncate block">{email.snippet}</span>
                    </td>

                    {/* Attachments */}
                    <td className="py-3.5 px-4">
                      {email.attachments.length > 0 ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]">
                          <FileText className="w-3 h-3 text-slate-400" />
                          {email.attachments.length} doc{email.attachments.length > 1 ? 's' : ''}
                        </span>
                      ) : (
                        <span className="text-slate-600 text-[11px]">None</span>
                      )}
                    </td>

                    {/* 7-Field Status */}
                    <td className="py-3.5 px-4">
                      {email.category !== 'compare_review' ? (
                        <span className="text-slate-500 text-[11px] italic">Bypassed (Non-doc request)</span>
                      ) : email.status === 'escalated' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          <AlertTriangle className="w-3 h-3" /> In Escalation Queue
                        </span>
                      ) : comp && comp.allMatched ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" /> No mismatch detected
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          <AlertOctagon className="w-3 h-3" /> Discrepancy Flagged
                        </span>
                      )}
                    </td>

                    {/* Action Button */}
                    <td className="py-3.5 px-4 text-right">
                      {email.category === 'compare_review' ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenStudio(email.id);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-medium transition-colors shadow-sm inline-flex items-center gap-1"
                        >
                          <span>Open Studio</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-slate-500 text-[11px]">Auto-Routed</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
