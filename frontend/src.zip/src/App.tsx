import React, { useState, useEffect } from 'react';
import { EmailRecord } from './types';
import { INITIAL_EMAILS } from './data/mockData';
import { Header } from './components/Header';
import { InboxView } from './components/InboxView';
import { VerificationStudio } from './components/VerificationStudio';
import { EscalationModal } from './components/EscalationModal';
import { CarrierAmendmentModal } from './components/CarrierAmendmentModal';
import { AnalyticsView } from './components/AnalyticsView';
import { CheckCircle2, Info, AlertTriangle } from 'lucide-react';

export const App: React.FC = () => {
  const [emails, setEmails] = useState<EmailRecord[]>(() =>
    JSON.parse(JSON.stringify(INITIAL_EMAILS))
  );
  const [activeEmailId, setActiveEmailId] = useState<string>('msg-001');
  const [activeTab, setActiveTab] = useState<'inbox' | 'studio' | 'escalations' | 'analytics'>('inbox');

  const [isEscalationOpen, setIsEscalationOpen] = useState(false);
  const [isAmendmentOpen, setIsAmendmentOpen] = useState(false);

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'warn' } | null>(
    null
  );

  const activeEmail = emails.find((e) => e.id === activeEmailId) || emails[0];
  const unreadCount = emails.length;
  const escalationCount = emails.filter((e) => e.status === 'escalated' || e.status === 'mismatch_flagged').length;

  const showToast = (message: string, type: 'success' | 'info' | 'warn' = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  const handleSelectEmail = (id: string) => {
    setActiveEmailId(id);
  };

  const handleOpenStudio = (id: string) => {
    setActiveEmailId(id);
    setActiveTab('studio');
    showToast('Loaded shipment into Verification Studio', 'info');
  };

  const handleApproveBL = () => {
    setEmails((prev) =>
      prev.map((e) => (e.id === activeEmailId ? { ...e, status: 'verified_match' } : e))
    );
    showToast('✓ Draft BL Approved! Confirmation sent to carrier.', 'success');
  };

  const handleEscalationSubmit = (action: string, notes: string) => {
    setEmails((prev) =>
      prev.map((e) => (e.id === activeEmailId ? { ...e, status: 'escalated' } : e))
    );
    setIsEscalationOpen(false);
    showToast('Escalated to Senior Ops with full audit trail', 'success');
    setActiveTab('escalations');
  };

  const handleSendAmendment = () => {
    setIsAmendmentOpen(false);
    showToast('Carrier amendment request dispatched!', 'success');
  };

  const handleResetData = () => {
    setEmails(JSON.parse(JSON.stringify(INITIAL_EMAILS)));
    setActiveEmailId('msg-001');
    setActiveTab('studio');
    showToast('Mock data reset to baseline test cases', 'info');
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === '1') setActiveTab('inbox');
      if (e.key === '2') setActiveTab('studio');
      if (e.key === '3') setActiveTab('escalations');
      if (e.key === '4') setActiveTab('analytics');
      if (e.key.toLowerCase() === 'e') setIsEscalationOpen(true);
      if (e.key.toLowerCase() === 'c') setIsAmendmentOpen(true);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased">
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        unreadCount={unreadCount}
        escalationCount={escalationCount}
        onReset={handleResetData}
      />

      <main className="flex-1 flex flex-col overflow-hidden">
        {activeTab === 'inbox' && (
          <InboxView
            emails={emails}
            activeEmailId={activeEmailId}
            onSelectEmail={handleSelectEmail}
            onOpenStudio={handleOpenStudio}
          />
        )}

        {activeTab === 'studio' && (
          <VerificationStudio
            email={activeEmail}
            onBack={() => setActiveTab('inbox')}
            onOpenEscalation={() => setIsEscalationOpen(true)}
            onOpenAmendment={() => setIsAmendmentOpen(true)}
            onApproveBL={handleApproveBL}
          />
        )}

        {activeTab === 'escalations' && (
          <div className="flex-1 flex flex-col p-6 max-w-7xl w-full mx-auto space-y-5 overflow-y-auto">
            <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 p-5 rounded-xl border border-amber-500/30 flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold text-sm shrink-0">
                  04
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                    Step 04: Human-in-the-Loop Escalation Console
                    <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Ask For Help Mode
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                    When extraction confidence is below threshold, critical discrepancies are flagged, or attachments cannot be automatically reconciled, items are routed here with complete contextual history instead of guessing or failing silently.
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Pending Review</span>
                <span className="text-xl font-bold text-amber-400">{escalationCount} Items</span>
              </div>
            </div>

            <div className="space-y-3">
              {emails
                .filter((e) => e.status === 'escalated' || e.status === 'mismatch_flagged')
                .map((e) => (
                  <div
                    key={e.id}
                    className="bg-slate-950 border border-slate-800 hover:border-amber-500/40 rounded-xl p-5 shadow-sm space-y-3 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="w-3 h-3 rounded-full bg-rose-500 animate-pulse"></span>
                        <h3 className="font-bold text-sm text-white">{e.subject}</h3>
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 font-mono">
                          {e.carrier}
                        </span>
                      </div>
                      <span className="text-xs text-rose-400 font-semibold">Priority: Urgent SLA</span>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <p className="text-xs text-slate-400">
                        Flagged Issue: <span className="text-slate-200">Container Count / Weight mismatch</span>
                      </p>
                      <button
                        onClick={() => handleOpenStudio(e.id)}
                        className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm"
                      >
                        Inspect in Studio &rarr;
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {activeTab === 'analytics' && <AnalyticsView />}
      </main>

      {/* Escalation Modal */}
      {activeEmail && (
        <EscalationModal
          email={activeEmail}
          isOpen={isEscalationOpen}
          onClose={() => setIsEscalationOpen(false)}
          onSubmit={handleEscalationSubmit}
        />
      )}

      {/* Carrier Amendment Modal */}
      {activeEmail && (
        <CarrierAmendmentModal
          email={activeEmail}
          isOpen={isAmendmentOpen}
          onClose={() => setIsAmendmentOpen(false)}
          onSend={handleSendAmendment}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-5 right-5 bg-slate-950 border border-slate-700 text-white text-xs px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50 animate-bounce">
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toast.type === 'warn' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
          {toast.type === 'info' && <Info className="w-4 h-4 text-indigo-400" />}
          <span>{toast.message}</span>
        </div>
      )}
    </div>
  );
};

export default App;
