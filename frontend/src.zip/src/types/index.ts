export type MessageCategory = 
  | 'compare_review'
  | 'returns'
  | 'it_requests'
  | 'invoice_queries'
  | 'prepare_si'
  | 'general_mail'
  | 'spam';

export type VerificationStatus = 
  | 'not_applicable'
  | 'pending'
  | 'verified_match'
  | 'mismatch_flagged'
  | 'escalated'
  | 'routed_finance'
  | 'routed_si_desk'
  | 'quarantined';

export interface Attachment {
  id: string;
  name: string;
  type: 'SI' | 'BL' | 'INV' | 'DOC' | 'OTHER';
  label: string;
  sizeBytes?: number;
}

export interface DocumentData {
  shipper: string;
  consignee: string;
  notifyParty: string;
  portOfLoading: string;
  portOfDischarge: string;
  containerCount: number;
  grossWeightKg: number;
  rawLines: string[];
}

export interface EmailRecord {
  id: string;
  subject: string;
  sender: string;
  carrier: string;
  receivedAt: string;
  category: MessageCategory;
  confidence: number;
  categoryName: string;
  snippet: string;
  emailBody: string;
  attachments: Attachment[];
  siData?: DocumentData;
  blData?: DocumentData;
  status: VerificationStatus;
}

export interface FieldComparison {
  key: string;
  label: string;
  siVal: string;
  blVal: string;
  match: boolean;
  type: 'exact' | 'semantic' | 'numeric';
  semanticNote?: string;
  detail: string;
}

export interface ComparisonResult {
  allMatched: boolean;
  mismatchCount: number;
  reportMessage: string;
  fields: FieldComparison[];
}

export interface EscalationPayload {
  emailId: string;
  reason: string;
  action: 'enforce_si' | 'accept_bl' | 'request_shipper' | 'reclassify';
  notes: string;
  operator: string;
  timestamp: string;
}
